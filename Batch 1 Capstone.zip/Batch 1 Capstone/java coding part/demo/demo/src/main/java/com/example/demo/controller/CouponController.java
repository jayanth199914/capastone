package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.CouponModel;
import com.example.demo.repo.CouponRepo;
@CrossOrigin(origins ="null", allowedHeaders = "*")
@RestController
@RequestMapping("/coupp")

public class CouponController {
	@Autowired
	private CouponRepo couponrepo ;
	
	 @PostMapping("/code")
	    public CouponModel createPayment(@RequestBody CouponModel couponcode) {
		 return couponrepo.save(couponcode);
	    }

}