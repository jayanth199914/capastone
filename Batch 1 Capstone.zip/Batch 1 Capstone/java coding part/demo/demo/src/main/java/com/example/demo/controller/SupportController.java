package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.SupportModel;
import com.example.demo.repo.SupportRepo;
@CrossOrigin(origins ="null", allowedHeaders = "*")
@RestController
@RequestMapping("/contt")
public class SupportController {

	@Autowired
	private SupportRepo supportrepo;
	
	 @PostMapping("/support")
	    public SupportModel createPayment(@RequestBody SupportModel supp) {
		 return supportrepo.save(supp);
	    }
}
