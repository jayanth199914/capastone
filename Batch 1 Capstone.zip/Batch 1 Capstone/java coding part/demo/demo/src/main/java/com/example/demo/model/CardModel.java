package com.example.demo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="card")
public class CardModel {

	@Column(name = "nameoncard")
	private String nameoncard;
	@Id
	@Column(name = "cardnumber")
	private int cardnumber;
	@Column(name = "expmonth")
	private int expmonth;
	@Column(name = "expyear")
	private int expyear;
	@Column(name = "cvv")
	private int cvv;
	public CardModel() {
		super();
		
	}
	public CardModel(String nameoncard, int cardnumber, int expmonth, int expyear, int cvv) {
		super();
		this.nameoncard = nameoncard;
		this.cardnumber = cardnumber;
		this.expmonth = expmonth;
		this.expyear = expyear;
		this.cvv = cvv;
	}
	public String getNameoncard() {
		return nameoncard;
	}
	public void setNameoncard(String nameoncard) {
		this.nameoncard = nameoncard;
	}
	public int getCardnumber() {
		return cardnumber;
	}
	public void setCardnumber(int cardnumber) {
		this.cardnumber = cardnumber;
	}
	public int getExpmonth() {
		return expmonth;
	}
	public void setExpmonth(int expmonth) {
		this.expmonth = expmonth;
	}
	public int getExpyear() {
		return expyear;
	}
	public void setExpyear(int expyear) {
		this.expyear = expyear;
	}
	public int getCvv() {
		return cvv;
	}
	public void setCvv(int cvv) {
		this.cvv = cvv;
	}
	
}
