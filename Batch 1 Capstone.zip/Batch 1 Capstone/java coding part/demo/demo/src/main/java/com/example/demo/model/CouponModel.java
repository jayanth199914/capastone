package com.example.demo.model;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="coupon")

public class CouponModel {

	@Id
	@Column(name = "couponid")
	private String couponid;
	@Column(name = "couponcode")
	private String couponcode;
	@Column(name = "coupondescription")
	private String coupondescription;
	@Column(name = "maximumlimit")
	private int maximumlimit;
	@Column(name = "expmonth")
	private int expmonth;
	@Column(name = "expyear")
	private int expyear;
	public CouponModel() {
		super();
	}
	public CouponModel(String couponid, String couponcode, String coupondescription, int maximumlimit, int expmonth,
			int expyear) {
		super();
		this.couponid = couponid;
		this.couponcode = couponcode;
		this.coupondescription = coupondescription;
		this.maximumlimit = maximumlimit;
		this.expmonth = expmonth;
		this.expyear = expyear;
	}
	public String getCouponid() {
		return couponid;
	}
	public void setCouponid(String couponid) {
		this.couponid = couponid;
	}
	public String getCouponcode() {
		return couponcode;
	}
	public void setCouponcode(String couponcode) {
		this.couponcode = couponcode;
	}
	public String getCoupondescription() {
		return coupondescription;
	}
	public void setCoupondescription(String coupondescription) {
		this.coupondescription = coupondescription;
	}
	public int getMaximumlimit() {
		return maximumlimit;
	}
	public void setMaximumlimit(int maximumlimit) {
		this.maximumlimit = maximumlimit;
	}
	public int getExpmonth() {
		return expmonth;
	}
	public void setExpmonth(int expmonth) {
		this.expmonth = expmonth;
	}
	public int getExpyear() {
		return expyear;
	}
	public void setExpyear(int expyear) {
		this.expyear = expyear;
	}
	
	
}
