package com.example.demo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="support")

public class SupportModel {
	
	@Column(name = "fullname")
	private String fullname;
	@Column(name = "email")
	private String email;
	@Id
	@Column(name = "orderid")
	private String orderid;
	@Column(name = "category")
	private String category;
	@Column(name = "subject")
	private String subject;
	public SupportModel() {
		super();
		
	}
	public SupportModel(String fullname, String email, String orderid, String category, String subject) {
		super();
		this.fullname = fullname;
		this.email = email;
		this.orderid = orderid;
		this.category = category;
		this.subject = subject;
	}
	public String getFullname() {
		return fullname;
	}
	public void setFullname(String fullname) {
		this.fullname = fullname;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getOrderid() {
		return orderid;
	}
	public void setOrderid(String orderid) {
		this.orderid = orderid;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	
	

}
